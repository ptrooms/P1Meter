#!/bin/bash
# Usage: compile.sh 1 ---> Generates user1.bin

app="0"
boot="none"
flashMap="6"
str_log=""
if [ "$1" == "1" ]; then
	echo "- Generating user1.bin"
	app="1"
	boot="new"
elif [ "$1" == "2" ]; then
	echo "- Generating user2.bin"
	app="2"
	boot="new"
else
	echo "- Generating eagle.irom0text.bin"
fi

if [[ $2 == *"2mb"* ]]; then
	echo "...Compiling For a 2MB Flash..."
	flashMap="5"
elif [[ $3 == *"2mb"* ]]; then
	echo "...Compiling For a 2MB Flash..."
	flashMap="5"
else
	echo "...Compiling For a 4MB Flash..."
fi


echo ""


# SIZE_MAP = 6 for 4MB flash
# SIZE_MAP = 5 for 2MB flash
make clean
make COMPILE=gcc BOOT=$boot APP=$app SPI_SPEED=80 SPI_MODE=QIO SPI_SIZE_MAP=$flashMap
