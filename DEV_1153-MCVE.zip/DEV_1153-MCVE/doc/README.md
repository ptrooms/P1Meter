# Notes

The files
```
- common_cpp.mk
- settings.mk
```

Must be added to the SDK's root directory since the default Make file does not support compilation of cpp files.

## IMPORTANT BEFORE COMPILING

You might need to make a few additions to some SDK files in order to compile a new WiFi firmware:

1)  `$(SDK_PATH)/include/ets_sys.h` Add the following right after the ETSTimer struct (~line 53):
    ```
    void ets_isr_unmask(uint32_t unmask);
    ```
and after `typedef void (* ets_isr_t)(void *);` ~line 66:

    ```
    void ets_isr_mask(uint32_t mask);   
    ```

2) in `$(SDK_PATH)/include/mem.h` add add the beginning after the first definition `#define __MEM_H__` ~line 28:
    ```
    #include <stddef.h>
    ```

# Compiling and uploading

1) In `main.h` define your interrupt pin (I2C_SDA_PIN)
2) In `main.cpp` (Line 82) set your ssid and pwd.
3) In settings.mk make sure you change the path for the xtensa compiler

4) Edit the file `configure_env.sh` to define the SDK's path then, make sure you run:
```
$ source ./configure_env.sh
```
To set the env vars.

Finally, just run:
    ```
    $ ./compile.sh 1 2mb
    ```
Where the second argument indicates the partition and 2mb the flash memory of the device (optional, default 4mb)

# It takes between 5 to 20 mins for the error to show up.