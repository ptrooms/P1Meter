// MCVE for https://github.com/espressif/ESP8266_NONOS_SDK/issues/90

extern "C"{	
	#include "os_type.h"
	#include "driver/uart.h"
	#include "gpio.h"
	#include "user_interface.h"
	#include "mem.h"
	#include "espconn.h"
	#include "wpa2_enterprise.h"
}

#include "main.h"



volatile int gpio_pin_register[16] = {
	PERIPHS_IO_MUX_GPIO0_U,		 	//0 
	PERIPHS_IO_MUX_U0TXD_U,		 	//1 
	PERIPHS_IO_MUX_GPIO2_U,		 	//2 
	PERIPHS_IO_MUX_U0RXD_U,		 	//3
	PERIPHS_IO_MUX_GPIO4_U,		 	//4 gpio 4 DHT 
	PERIPHS_IO_MUX_GPIO5_U,		 	//5 gpio 5 buzzer 
	PERIPHS_IO_MUX_SD_CLK_U,	 	//6
	PERIPHS_IO_MUX_SD_DATA0_U, 	// 7
	PERIPHS_IO_MUX_SD_DATA1_U, 	// 8
	PERIPHS_IO_MUX_SD_DATA2_U, 	// 9 gpio 9
	PERIPHS_IO_MUX_SD_DATA3_U, 	// 10 gpio 10
	PERIPHS_IO_MUX_SD_CMD_U, 		// 11
	PERIPHS_IO_MUX_MTDI_U, 			// 12 gpio12 blue
	PERIPHS_IO_MUX_MTCK_U, 			// 13 gpio13 green
	PERIPHS_IO_MUX_MTMS_U, 			// 14 gpio14 white
	PERIPHS_IO_MUX_MTDO_U       // 15 gpio15 red??
}; 


os_timer_t debugMsgTmr;
os_event_t *systemTasks;	
volatile bool _connected = false;

/**
 * Changes the mode of a pin (input/output)
 */
void setMode(uint8_t pin, uint8_t mode){
	if ((0x1 << pin) & 0b110101) {
		PIN_FUNC_SELECT(gpio_pin_register[pin], 0); //0,2,4,5
	} else {
		PIN_FUNC_SELECT(gpio_pin_register[pin], 3);
	}
	
	// No Pullups
	PIN_PULLUP_DIS(gpio_pin_register[pin]);

	if (mode) {		// 1 == Input, 0 == Output
		GPIO_REG_WRITE(GPIO_ENABLE_W1TC_ADDRESS, 1<<pin); // GPIO input
	} else {
		GPIO_REG_WRITE(GPIO_ENABLE_W1TS_ADDRESS, 1<<pin); // GPIO output
	}
}

/**
 * Entry point
 */
int ICACHE_FLASH_ATTR main(){
	uart_div_modify(0, UART_CLK_FREQ / 115200);
	os_delay_us(100);
	
	os_printf("\n\n**** System started *****\n");

	system_update_cpu_freq(160);
	system_init_done_cb(posSysInit);
}

/**
 * After system_init_done!
 */
void ICACHE_FLASH_ATTR posSysInit(){
	// Setup the task queue
	systemTasks = (os_event_t	*) os_malloc(sizeof(os_event_t) * 15);
	system_os_task(taskHandler, USER_TASK_PRIO_0, systemTasks, 15);

	const char *ssid = "";					// <<<<< Fill me up
	const char *pwd = "";

	os_printf("\n>>>> No AP credentials defined!!! LINE 85 <<<<\n\n");
	return;

	connectToAP(ssid, pwd);

	// Print something to make sure this is working
	os_timer_disarm(&debugMsgTmr);
	os_timer_setfn(&debugMsgTmr, (os_timer_func_t* ) printDebugMsg, NULL);
	os_timer_arm(&debugMsgTmr, 2000, true);
}


void ICACHE_FLASH_ATTR connectToAP(const char *ssid, const char *pass){
	struct station_config stationConf;
	
	os_memset(&stationConf, 0, sizeof(struct station_config));		// Clear memory
	os_memcpy(stationConf.ssid, ssid, strlen(ssid));						// Copy credentials
	os_memcpy(stationConf.password, pass, strlen(pass));
	wifi_set_opmode_current(STATION_MODE);
	wifi_station_set_config_current(&stationConf);

	wifi_station_set_wpa2_enterprise_auth(0);		// Disable enterprise authentication
	wifi_station_set_reconnect_policy(true);

	wifi_set_event_handler_cb(onWiFiEvent);
	wifi_station_connect();
}


void ICACHE_FLASH_ATTR taskHandler(os_event_t	*e){
	switch(e->sig)	{
		case WIFI_CONNECTED_TO_AP:
			wifiOnConnected();
			break;
	}
}

/**
 * WiFi events handler
 */
void onWiFiEvent(System_Event_t *evt){
	
	switch	(evt->event)	{
		case	EVENT_STAMODE_CONNECTED:
			os_printf("connect	to	ssid	%s,	channel	%d\n",	
			evt->event_info.connected.ssid,	
			evt->event_info.connected.channel);
			// At this point we are connected but no IP has been 
			// given yet, so we wait....
			break;
		case	EVENT_STAMODE_GOT_IP:
			system_os_post(USER_TASK_PRIO_0, WIFI_CONNECTED_TO_AP, 0);
			break;
		case	EVENT_STAMODE_DISCONNECTED:
			os_printf("disconnect	from	ssid	%s,	reason	%d\n",	
			evt->event_info.disconnected.ssid,	
			evt->event_info.disconnected.reason);
			
			if(evt->event_info.disconnected.reason == REASON_4WAY_HANDSHAKE_TIMEOUT){
				os_printf("STATION_WRONG_PASSWORD\n");
			}else if(evt->event_info.disconnected.reason == REASON_NO_AP_FOUND){
				os_printf("STATION_NO_AP_FOUND\n");
			}else if(evt->event_info.disconnected.reason == REASON_BEACON_TIMEOUT){
				os_printf("Connection Failed\n");
			}else{
				// Unknown
			}

			break;
	}
}


// Re-enable interrupts
void _interrupt_re_enable(){
	gpio_pin_intr_state_set(I2C_SDA_PIN, (GPIO_INT_TYPE) GPIO_PIN_INTR_NEGEDGE);	
}


/**
 * Pause interrupts, call user's isr
 */
void _main_isr(void *arg){
	ETS_GPIO_INTR_DISABLE();
	uint32_t	gpio_status	=	GPIO_REG_READ(GPIO_STATUS_ADDRESS);
	gpio_pin_intr_state_set(I2C_SDA_PIN, (GPIO_INT_TYPE) GPIO_PIN_INTR_DISABLE);
	uint8_t _int_pin_state = GPIO_INPUT_GET(I2C_SDA_PIN);
	// Do something with pin
	_on_interrupt(_int_pin_state, I2C_SDA_PIN);
	//clear	interrupt	status
	GPIO_REG_WRITE(GPIO_STATUS_W1TC_ADDRESS, gpio_status & BIT(I2C_SDA_PIN));
	// Re-enable interrupts
	ETS_GPIO_INTR_ENABLE();
}


/****** Just a couple of empty buffers to move bytes around ****/
uint8_t _i2c_buffer[2024];
volatile uint16_t _i2c_buf_offset = 0;
uint8_t _i2c_dummy[552];
volatile uint8_t _i2c_dummy_offset = 0;
volatile uint8_t _irq_state = 0;
/**************************************************************/

/**
 * User's ISR
 */
void _on_interrupt(uint8_t state, uint8_t pin){
	
	// All setPinState(DEBUG_LINE, x) are for debugging purposes 
	// to check when this ISR is triggered and for how long it lasts
	setPinState(DEBUG_LINE, 0);

	// Disable future interrupts while reading data (in case this is fired twice?)
	if(_irq_state) {
		setPinState(DEBUG_LINE, 1);
		_interrupt_re_enable();
		return;	// Another interrupt is currently in effect
	}

	_irq_state = 1;

	// Do something for 6ms....
	uint32_t start = system_get_time();
	uint16_t usTimeout = 6000;

	while((system_get_time() - start) < usTimeout){
		// Simulate some activity moving bytes around
		os_memcpy(&_i2c_buffer[_i2c_buf_offset], &_i2c_dummy[_i2c_dummy_offset], 23);

		_i2c_dummy_offset += 23;
		_i2c_buf_offset += 23;

		if(_i2c_buf_offset >= SO(_i2c_buffer)) _i2c_buf_offset = 0;
		if(_i2c_dummy_offset >= SO(_i2c_dummy)) _i2c_dummy_offset = 0;
	} 
	

	setPinState(DEBUG_LINE, 1);	
	_interrupt_re_enable();
	_irq_state = 0;
}


/**
 * Enables interrupt for the interrupt pin (pin 5)
 */
void ICACHE_FLASH_ATTR armI2CBus(){
	os_printf("Arming i2c bus...\n");
	
	gpio_pin_intr_state_set(I2C_SDA_PIN, (GPIO_INT_TYPE) GPIO_PIN_INTR_NEGEDGE);
	ETS_GPIO_INTR_ATTACH(_main_isr, NULL);
	ETS_GPIO_INTR_DISABLE();

	// Debug line to check when the isr is called
	setMode(DEBUG_LINE, MODE_OUTPUT);
	setPinState(DEBUG_LINE, 1);

	os_printf("I2C Initialized, Free memory: %d\n", system_get_free_heap_size());
}

/**
* Triggered when the WiFi module is connected
* to an access point.
*/
void ICACHE_FLASH_ATTR wifiOnConnected(){
	os_printf("Connected to AP!\n");
	
	armI2CBus();

	ETS_GPIO_INTR_ENABLE();		// Enable interrupts
}


uint32_t _stuff_counter = 0;
void ICACHE_FLASH_ATTR printDebugMsg(){
	os_printf("Doing stuff x%d\n", _stuff_counter++);
}

void setPinState(uint8_t pin, uint8_t state){
	if (state) {
		GPIO_REG_WRITE(GPIO_OUT_W1TS_ADDRESS, 1<<pin); // set GPIO pin high
	} else {
		GPIO_REG_WRITE(GPIO_OUT_W1TC_ADDRESS, 1<<pin); // set GPIO pin low
	}
}
