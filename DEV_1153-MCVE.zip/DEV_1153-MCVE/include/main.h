
#include "c_types.h"
#include <math.h>	

extern "C"{
	#include "user_interface.h"
	#include "hw_timer.h"
	#include "eagle_soc.h"
  #include "osapi.h"

  #include "ets_sys.h"
  #include "os_type.h"
	#include "mem.h"
	#include "gpio.h"
}


#define I2C_SDA_PIN               5   // External interrupt pin
#define SO(x) (sizeof(x))

#define MODE_OUTPUT 	0
#define MODE_INPUT 		1
#define DEBUG_LINE 		2								// Pin 2 is used to flag when the ISR was called (debugging purposes only)
#define WIFI_CONNECTED_TO_AP			310		


int main();
void printDebugMsg();
void wifiOnConnected();
void taskHandler(os_event_t	*e);
void sendPowerUpEvent();
void armPowerUpTimer();
void printBuffer(uint8_t *data, uint16_t size, bool newLine=false);
void posSysInit();
void connectToAP(const char *ssid, const char *pwd);

void armI2CBus();
void TCPReconnect();


void onWiFiEvent(System_Event_t *evt);

void _on_interrupt(uint8_t state, uint8_t pin);
void _interrupt_re_enable();
void _main_isr(void *arg);
void setPinState(uint8_t pin, uint8_t state);