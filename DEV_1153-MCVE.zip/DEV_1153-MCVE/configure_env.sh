export SDK_PATH=/ADD_YOUR_PATH_HERE/ESP8266_NONOS_SDK_v2.1.0
export BIN_PATH=$(PWD)/bin
export PATH=/Volumes/dev-case-sensitive/esp-open-sdk/xtensa-lx106-elf/bin:$PATH